import RightPanel from '../RightPanel';

export default function RightPanelExample() {
  return (
    <div className="w-full min-h-screen bg-background flex justify-end">
      <RightPanel />
    </div>
  );
}
