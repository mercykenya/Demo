import ObjectivesPanel from '../ObjectivesPanel';

export default function ObjectivesPanelExample() {
  return (
    <div className="w-full min-h-screen bg-background p-4">
      <ObjectivesPanel />
    </div>
  );
}
